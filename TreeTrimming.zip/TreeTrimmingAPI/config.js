module.exports = {
    name: "Tree Trimming Rest API",
    db: {
        "server":"dotb6gisdb01",
        "user": "TreeTrimming",
        "password":"destroy-pounds-JULY-CHECK",
        "database": "TreeTrimming"
    }
};